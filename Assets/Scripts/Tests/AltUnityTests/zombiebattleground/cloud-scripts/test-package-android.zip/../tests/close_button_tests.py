import unittest
from appium import webdriver
from altunityrunner import AltrunUnityDriver, AltElement
import xmlrunner
from base import CZBTests
import time

class CZBCloseButtonTests(CZBTests):

    def setUp(self):
        super(CZBCloseButtonTests, self).setUp()
        self.pass_authentification()

    def test_close_button(self):
   
        self.altdriver.wait_for_element('Button_Quit').mobile_tap()
        
        self.altdriver.wait_for_element('ConfirmationPopup(Clone)')
        self.altdriver.wait_for_element('Text_Message')
        self.altdriver.wait_for_element('Button_Yes')
        no_button = self.altdriver.wait_for_element('Button_No')
        
        self.driver.save_screenshot('./screenshots/confirmation-dialog.png')
        no_button.mobile_tap()
        
        self.altdriver.wait_for_element('Button_Quit').mobile_tap()
        self.altdriver.wait_for_element('Button_Yes').mobile_tap()
        time.sleep(5)
        self.assertNotIn("games.loom.battleground", self.driver.page_source)
        
if __name__ == '__main__':
    unittest.main(testRunner=xmlrunner.XMLTestRunner(output='test-reports'))