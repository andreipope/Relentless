﻿using UnityEngine;

namespace Loom.Blackjack
{
    public class PlayerPositionsContainer : MonoBehaviour
    {
        public RectTransform Dealer;
        public RectTransform[] Players;
    }
}