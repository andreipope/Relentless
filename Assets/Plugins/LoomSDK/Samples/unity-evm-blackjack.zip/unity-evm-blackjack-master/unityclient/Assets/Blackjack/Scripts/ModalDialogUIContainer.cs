﻿using UnityEngine;
using UnityEngine.UI;

namespace Loom.Blackjack
{
    public class ModalDialogUIContainer : MonoBehaviour
    {
        public Text Title;
        public Text Text;
        public Button OKButton;
    }
}
