﻿namespace Loom.Blackjack
{
    public enum PlayerDecision {
        Stand,
        Hit
    }
}