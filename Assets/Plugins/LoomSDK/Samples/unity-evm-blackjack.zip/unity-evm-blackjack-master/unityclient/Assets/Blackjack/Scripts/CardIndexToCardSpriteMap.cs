﻿using UnityEngine;

namespace Loom.Blackjack
{
    [CreateAssetMenu]
    public class CardIndexToCardSpriteMap : ScriptableObject
    {
        public Sprite[] CardSprite;
    }
}