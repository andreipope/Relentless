﻿namespace Loom.Blackjack
{
    public enum PlayerRole
    {
        Dealer,
        Player
    }
}