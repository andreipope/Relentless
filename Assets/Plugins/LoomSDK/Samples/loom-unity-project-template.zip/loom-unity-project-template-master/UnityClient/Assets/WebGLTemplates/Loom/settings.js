window.LOOM_SETTINGS = {
  transferAsset: null
}
