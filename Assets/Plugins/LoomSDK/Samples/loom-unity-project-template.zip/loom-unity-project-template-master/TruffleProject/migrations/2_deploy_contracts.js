var Blueprint = artifacts.require("./Blueprint.sol");

module.exports = function(deployer) {
    deployer.deploy(Blueprint);
};