set -e

./start-chain.sh reset